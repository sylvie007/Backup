  
Readme for tagging script.
____________________________________________________________________________________


   cd /home/ubuntu/
   chmod u=rwx,g=r,o=r BUILD_AND_TAG.sh
   sed -i -e 's/\r$//' BUILD_AND_TAG.sh

 - Build docker image of specific (e.g GIN) repository:
    ./TAG.sh GITHUB_USER_NAME=rajeshvkothari GITHUB_TOKEN=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 TAG_NAME=23.Nov.2023 COMPONENT_NAME=gin
  
 - Build docker image of specific repository also Tag specific git repositories:
    ./BUILD_AND_TAG.sh GITHUB_USER_NAME=rajeshvkothari GITHUB_TOKEN=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 TAG_NAME=23.Nov.2023 COMPONENT_NAME=tel-client GIT_TAG_FLAG=true
  
 - Build docker image of all repositories:
    ./TAG.sh GITHUB_USER_NAME=rajeshvkothari GITHUB_TOKEN=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 TAG_NAME=23.Nov.2023 COMPONENT_NAME=all
  
 - Build docker image of all repositories and Tag all git repositories:
    ./TAG.sh GITHUB_USER_NAME=rajeshvkothari GITHUB_TOKEN=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 TAG_NAME=1.9.0 GIT_TAG_FLAG=true