#!/bin/bash

for ARGUMENT in "$@"
do
    KEY=$(echo $ARGUMENT | cut -f1 -d=)
    VALUE=$(echo $ARGUMENT | cut -f2 -d=)

    case "$KEY" in
            aws_instance_name)               aws_instance_name=${VALUE} ;;
            domain_name)                     domain_name=${VALUE} ;;
            enable_ssl)                      enable_ssl=${VALUE} ;;
            service_mesh)                    service_mesh=${VALUE} ;;
            existing_server_ip)              existing_server_ip=${VALUE} ;;
            cci_repo_ip)                     cci_repo_ip=${VALUE} ;;
            *)
    esac
done

ansible-playbook setup-gin-server.yml -e 'ansible_python_interpreter=/usr/bin/python3' --extra-vars  "aws_instance_name=$aws_instance_name" --extra-vars  "domain_name=$domain_name" --extra-vars  "enable_ssl=$enable_ssl" --extra-vars  "service_mesh=$service_mesh" --"existing_server_ip=$existing_server_ip" --extra-vars  "cci_repo_ip=$cci_repo_ip" --vault-password-file=vault-pwd.txt -i /opt/app/gin-deployments/gin-ansible/ansible-hosts.txt